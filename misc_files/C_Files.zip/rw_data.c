/*****************************************************************/
/*   Copyright (C) 2000, Mueller BBM VibroAkustik Systeme GmbH   */
/*   All rights reserved.                                        */
/*   This is code to read and write data via the binary          */
/*   programing interface to the arithmetic module of PAK (R)    */
/*   used by READ_DATA_FILE() and  WRITE_DATA_FILE().            */
/*   For improvements this code may be subject to changes in     */
/*   future versions.                                            */
/*****************************************************************/

/* Revision 1.3  2001/04/04 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>

#include <sys/types.h>
#include <sys/stat.h>

#ifdef WIN32
#include <io.h>
#define mode_t int
#else
#include <unistd.h>
#endif

#define _MAIN_rw_data
#include "rw_data.h"

static int pakBinFileVersion;
static int needByteSwap;

/***********************************************************/
/* The following functions for reading and writing data    */
/* have to be called in correct order, since they assume,  */
/* that the file descriptor is positioned correctly in the */
/* file. (This is fullfilled automatically if the read-    */
/* functions are called correct order according to the     */
/* specification of the pakBinFile)                        */
/***********************************************************/


/*###########################################################*/
/* Supplementary functions                                   */
/*###########################################################*/

/************************************************************/
/* Provide Byte-Swpping for an array of data                */
/************************************************************/
static void swapArray(void *data, int nElem, int elemSize)
{
   char *a;
   
   char byte;
   int elem, i, j, k;
   
   if (elemSize%2 == 1)
      k = (elemSize -1)/2;
   else
      k = elemSize/2;
   
   for(elem=0; elem<nElem; elem++) {
      a = (char *)data + elem*elemSize;
      for(i=0, j=elemSize-1; i<k; i++, j--) {
	 byte = a[i];
	 a[i] = a[j];
	 a[j] = byte;
      }
   }
}

/******************************************************/
/*  Free complete binPakData-Structure                */
/******************************************************/
void freeBinPakData(struct binPakData* pData)
{
   long i;
   
   if (pData == (struct binPakData*)NULL)
      return;
   
   if (pData->xdata != (double*)NULL)
      free(pData->xdata);
   if (pData->zdata != (double*)NULL)
      free(pData->zdata);
   
   if (pData->ydata != (double**)NULL) {
      for (i=0; i<pData->nz; i++) {
	 if(pData->ydata[i] != (double*)NULL)
	    free(pData->ydata[i]);
      }
      free(pData->ydata);
   }
   free (pData);
}

/*###########################################################*/
/*  Functions for opening and closing PAK binary files       */
/*###########################################################*/

/**************************************************/
/* Open pakBinFile                                */
/* Read and check Byteorder and FileVersion       */
/* Read number of DatasetArrays in File           */
/* returns pakFileHandle df or                    */
/* Error during file open  -1                     */
/* Invalid Fileversion     -2                     */
/* No valid Byteorder      -3                     */
/* File is closed in case of errror               */
/**************************************************/
int openPakBinFile(char *filename, short *nDataArrays, int oMode)
{
   mode_t m;
   int df, openMode, bytesRead, endian, littleEndian;
   struct {
      char  byteOrder[8];
      short version;
      short nDataArrays;
      long  pad;
   } inRead;
   
   /* Evaluate opening mode of file */
   switch (oMode) {
      case READ:   openMode = O_RDONLY;  break;
      case WRITE:  openMode = O_WRONLY | O_CREAT;  break;
   }
   
#ifdef WIN32
   openMode |= O_BINARY;
#endif   
   
   m = umask(0);
   (void)umask(m);
   
   df = open(filename, openMode, (0666 & ~m));
   if (df < 0)
      return -1;
   if (oMode == WRITE) 
      return df;
   
   /* ---> Read header of datafile */
   bytesRead = read(df, (void*)&inRead, (unsigned)sizeof(inRead));
   if (bytesRead != sizeof(inRead)) {
      close (df);
      return -1;
   }
   
   /* Check Endian-Type of machine programm is running on 
      and set info for byte swap */
   endian = 1;
   littleEndian = *((char *)(&endian));
   if (strncmp(inRead.byteOrder, "LSB", 3) == 0) {
      if (littleEndian)
	 needByteSwap = 0;
      else
	 needByteSwap = 1;
   }
   else if (strncmp(inRead.byteOrder, "MSB", 3) == 0) {
      if (littleEndian)
	 needByteSwap = 1;
      else
	 needByteSwap = 0;
   }
   /* ---> Invalid byteOrder-Entry in file */
   else { 
      close (df);
      return -3;
   }
   
   /* ---> Read and swap version of file */   
   if(needByteSwap)
      swapArray((void*)&inRead.version, (int)1, sizeof(inRead.version));
   pakBinFileVersion = inRead.version;
   if (pakBinFileVersion > SUPPORTED_PAK_BIN_VERSION) {
      close (df);
      return -2;
   }
   
   /* Read and swap number of data arrays in file */   
   if(needByteSwap)
      swapArray((void*)&inRead.nDataArrays, (int)1, sizeof(inRead.nDataArrays));
   *nDataArrays = inRead.nDataArrays;
   
   return df;
}

/**************************************************/
/* Close pakBinFile                               */
/**************************************************/
void closePakBinFile(int df)
{
   close (df);
}

/*###########################################################*/
/*  Functions for reading PAK binary files                   */
/*###########################################################*/

/**************************************************/
/* Read number of dataSets in actual DataSetArray */
/* return value ok >= 0 or error -1               */
/**************************************************/
int readDataSetHeader(int df, long *nDataSets)
{
   long arrayHead[2];
   int bytesRead;
   
   bytesRead = read(df, (void*)arrayHead, (unsigned)sizeof(arrayHead));
   if (bytesRead != sizeof(arrayHead))
      return -1;
   
   if (needByteSwap)
      swapArray((void*)arrayHead, sizeof(arrayHead)/sizeof(long), sizeof(long));
   *nDataSets = arrayHead[0];
   return 0;
}

/**************************************************/
/* Read name string of actual dataSet.            */
/* Memory in dsName must be provided by calling   */
/* function (min. 256 Byte expected)              */
/* return value ok >= 0 or error -1               */
/**************************************************/
int readDataSetName(int df, char *dsName)
{
   int bytesRead;
   
   bytesRead = read(df, (void*)dsName, (unsigned)256);
   if (bytesRead != 256)
      return -1;
   else
      return 0;
   
}
 
/**************************************************/
/* Read info on single array of x, y or z-Values. */
/* Necessary Byte-Swapping will be applied.       */
/* Return value:                                  */
/* return value ok >= 0 or error -1               */
/**************************************************/
int readDataSetDataInfo(int df, int *cplx, long *nVal)
{
   int bytesRead;
   struct {
      short cplx;
      short  pad;
      long  lCnt;
   } readBuff;
   
   bytesRead = read(df, (void*)&readBuff, (unsigned)sizeof(readBuff));
   if (bytesRead != sizeof(readBuff))
      return -1;
   if (needByteSwap) {
      swapArray((void*)&readBuff.cplx, (int)1, sizeof(readBuff.cplx));
      swapArray((void*)&readBuff.lCnt, (int)1, sizeof(readBuff.lCnt));
   }
   
   *cplx = readBuff.cplx;
   *nVal = readBuff.lCnt;
   
   return 0;
}

/**************************************************/
/* Read single array of x, y or z-Values.         */
/* Necessary Byte-Swapping will be applied.       */
/* Memory for the returned double pointer is      */
/* allocated by readDataSetDataValues.            */
/* Return value:                                  */
/*       sucess:  ret != (double*)NULL            */
/*       failure: ret == (double*)NULL            */
/**************************************************/
double *readDataSetDataValues(int df, int cplx, long nVal)
{
   int bytesRead, bytesToRead;
   double *data;
   
   bytesToRead = cplx * nVal * sizeof(double);
   
   /* ---> allocate memory for data */
   data = (double*)malloc((size_t)bytesToRead);
   if (data == (double*)NULL) {
      return (double*)NULL;
   }
   
   /* ---> Read Data */
   bytesRead = read(df, (void*)data, (unsigned)bytesToRead);
   if (bytesRead != bytesToRead) {
      free(data);
      return (double*)NULL;
   }
   if (needByteSwap)
      swapArray((void*)data, bytesToRead/sizeof(double), sizeof(double));
   
   return data;
}

/**************************************************/
/* Read data of actual dataSet.                   */
/* Memory for the returned pointer to struct      */
/* binPakData is allocated by readDataSetData.    */
/* It can be freed by calling freeBinPakData().   */
/* Return value:                                  */
/*       sucess:  ret != (struct binPakData*)NULL */
/*       failure: ret == (struct binPakData*)NULL */
/**************************************************/
struct binPakData *readDataSetData(int df)
{
   long i, dummy;
   struct binPakData *pData;
   
   /* ---> Create data structure and reset all elems to zero */
   pData = (struct binPakData*)calloc((size_t)1, sizeof(struct binPakData));
   if (pData == (struct binPakData*)NULL)
      return pData;
   
   /* ====> X-DATA */
   /* ---> Read info on x-Data */
   if (readDataSetDataInfo(df, &(pData->xCplx), &(pData->nx)) < 0) {
      freeBinPakData(pData);
      return (struct binPakData*)NULL;
   }

   /* ---> Read x-Data values */
   pData->xdata = readDataSetDataValues(df, pData->xCplx, pData->nx);
   if (pData->xdata == (double*)NULL) {
      freeBinPakData(pData);
      return (struct binPakData*)NULL;
   }
   
   /* ====> Z-DATA */
   /* ---> Read info on z-Data */
   if (readDataSetDataInfo(df, &(pData->zCplx), &(pData->nz)) < 0) {
      freeBinPakData(pData);
      return (struct binPakData*)NULL;
   }
   /* ---> Read z-Data values */
   pData->zdata = readDataSetDataValues(df, pData->zCplx, pData->nz);
   if (pData->zdata == (double*)NULL) {
      freeBinPakData(pData);
      return (struct binPakData*)NULL;
   }
   
   /* ====> Y-DATA */
   /* ---> Read info on y-Data */
   if (readDataSetDataInfo(df, &(pData->yCplx), &dummy) < 0) {
      freeBinPakData(pData);
      return (struct binPakData*)NULL;
   }
   
   /* ---> allocate memory for ydata Array */
   pData->ydata = (double**)calloc((size_t)(pData->nz), sizeof(double*));
   if (pData->ydata == (double**)NULL) {
      freeBinPakData(pData);
      return (struct binPakData*)NULL;
   }
   
   /* ---> Read y-Data values */
   for (i=0; i<pData->nz; i++) {
      pData->ydata[i] = readDataSetDataValues(df, pData->yCplx, pData->nx);
      if (pData->ydata[i] == (double*)NULL) {
	 freeBinPakData(pData);
	 return (struct binPakData*)NULL;
      }
   }
   
   return pData;
}

/**************************************************/
/* Read actual dataSet in file df including name  */
/* and data.                                      */
/* Memory for the returned pointer to struct      */
/* binPakData is allocated by readDataSetData.    */
/* It can be freed by calling freeBinPakData().   */
/*       sucess:  ret != (struct binPakData*)NULL */
/*       failure: ret == (struct binPakData*)NULL */
/**************************************************/
struct binPakData *readOneDataSet(int df)
{  
   char nameBuff[256];
   struct binPakData *pData;
   int ret; 
   
   ret = readDataSetName(df, nameBuff);
   
   if (ret < 0)
      pData = (struct binPakData*)NULL;
   else
      pData = readDataSetData(df);
   
   if (pData != (struct binPakData*)NULL)
      (void)strcpy(pData->name, nameBuff);
   
   return pData;
}

/*###########################################################*/
/*  Functions for writing PAK binary files                   */
/*###########################################################*/

/**************************************************/
/* write Header for a pakBinFile                  */
/* Evaluate byteorder automatically               */
/* return value ok >= 0 or error -1               */
/**************************************************/
int writePakBinFileHeader(int df, short nDataArrays)
{
   int bytesWritten, endian, littleEndian;
   struct {
      char  byteOrder[8];
      short version;
      short nDataArrays;
      long  pad;
   } outWrite;
   
   /* Check Endian-Type of machine programm is running on 
      and set info for byte swap */
   endian = 1;
   littleEndian = *((char *)(&endian));
   (void)memset((void*)outWrite.byteOrder, 0, sizeof(outWrite.byteOrder));
   if (littleEndian)
      (void)strcpy(outWrite.byteOrder, "LSB");
   else
      (void)strcpy(outWrite.byteOrder, "MSB");
   
   outWrite.version     = 1;
   outWrite.nDataArrays = nDataArrays;
   outWrite.pad         = 0;
   
   /* ---> Write header of datafile */
   bytesWritten = write(df, (void*)&outWrite, (unsigned)sizeof(outWrite));
   if (bytesWritten != sizeof(outWrite))
      return -1;
   
   return 0;
}

/****************************************************/
/* Write number of dataSets for actual dataSetArray */
/* return value ok >= 0 or error -1                 */
/****************************************************/
int writeDataSetHeader(int df, long nDataSets)
{
   long arrayHead[2];
   int bytesWritten;
   
   arrayHead[0] = nDataSets;
   arrayHead[1] = 0;
   
   bytesWritten = write(df, (void*)arrayHead, (unsigned)sizeof(arrayHead));
   if (bytesWritten != sizeof(arrayHead))
      return -1;
   return 0;
}

/**************************************************/
/* Write name string of actual dataSet.           */
/* dsName must be shorter than 256 characters.    */
/* return value ok >= 0 or error -1               */
/**************************************************/
int writeDataSetName(int df, char *dsName)
{
   int bytesWritten;
   char name[256];
   
   if (strlen(dsName) > 255)
      return -1;
   else {
      (void)memset(name, 0, sizeof(name));
      (void)strcpy(name, dsName);
   }
   bytesWritten = write(df, (void*)name, (unsigned)256);
   if (bytesWritten != 256)
      return -1;
   else
      return 0;
   
}

/**************************************************/
/* Write info on single array of x y or z-Values. */
/* Return value:                                  */
/* return value ok >= 0 or error -1               */
/**************************************************/
int writeDataSetDataInfo(int df, int cplx, long nVal)
{
   int bytesWritten;
   struct {
      short cplx;
      short pad;
      long lCnt;
   } writeBuff;
   
   writeBuff.cplx = (short)cplx;
   writeBuff.pad  = 0;
   writeBuff.lCnt = nVal;
   bytesWritten = write(df, (void*)&writeBuff, (unsigned)sizeof(writeBuff));
   if (bytesWritten != sizeof(writeBuff))
      return -1;
   
   return 0;
}

/**************************************************/
/* Write single array of x, y or z-Values.        */
/* Return value:                                  */
/* return value ok >= 0 or error -1               */
/**************************************************/
int writeDataSetDataValues(int df, int cplx, long nVal, double *data)
{
   int bytesWritten, bytesToWrite;
   
   if (data != (double*)NULL) {
      bytesToWrite = cplx * nVal * sizeof(double);
      bytesWritten = write(df, (void*)data, (unsigned)bytesToWrite);
      if (bytesWritten != bytesToWrite)
	 return -1;
   }
   else
      return -1;
   
   return 0;
}

/**************************************************/
/* Write data from pData as actual dataSet.       */
/* Return value:                                  */
/* return value ok >= 0 or error -1               */
/**************************************************/
int writeDataSetData(int df, struct binPakData *pData)
{
   long i;
   
   if (pData == (struct binPakData*)NULL)
      return -1;
   
   /* ====> X-DATA */
   /* ---> Write info on x-Data */
   if (writeDataSetDataInfo(df, pData->xCplx, pData->nx) < 0)
      return -1;
   
   /* ---> Write x-Data */
   if (writeDataSetDataValues(df, pData->xCplx, pData->nx, pData->xdata) < 0)
      return -1;
   
   /* ====> Z-DATA */
   /* ---> Write info on z-Data */
   if (writeDataSetDataInfo(df, pData->zCplx, pData->nz) < 0)
      return -1;
   
   /* ---> Write z-Data */
   if (writeDataSetDataValues(df, pData->zCplx, pData->nz, pData->zdata) < 0)
      return -1;
   
   /* ====> Y-DATA */
   /* ---> Write info on y-Data */
   if (writeDataSetDataInfo(df, pData->yCplx, (long)0) < 0)
      return -1;

   if (pData->ydata != (double**)NULL) {
      /* ---> write y-Data */
      for (i=0; i<pData->nz; i++) {
	 if (writeDataSetDataValues(df, pData->yCplx, pData->nx, pData->ydata[i]) < 0)
	    return -1;
      }
   }
   else 
      return -1;
   
   return 0;
}

/**************************************************/
/* Write actual dataSet in file df including name */
/* and data.                                      */
/*       sucess:  ret >=  0                       */
/*       failure: ret  = -1                       */
/**************************************************/
int writeOneDataSet(int df, struct binPakData *pData)
{  
   int ret; 
   
   ret = writeDataSetName(df, pData->name);
   if (ret >= 0)
      ret = writeDataSetData(df, pData);
   
   return ret;
}
