/*****************************************************************/
/*   Copyright (C) 2000, Mueller BBM VibroAkustik Systeme GmbH   */
/*   All rights reserved.                                        */
/*   This is sample code to manipulate data read from the binary */
/*   programing interface to the arithmetic module of PAK (R)    */
/*****************************************************************/

/* Revision 1.2  2000/08/22 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
//Clipboard includes
#include <windows.h>
//#include <condefs.h>
#include "rw_data.h"



int main(int argc, char **argv)
{
   char *ifile, *ofile;
   short nDataArrays, dummy;
   long  nDataSets;
   struct binPakData *inDataSet;
   int df_i, df_o, ret;

   ifile = argv[1];
   ofile = argv[2];

   df_i = openPakBinFile(ifile, &nDataArrays, READ);
   df_o = openPakBinFile(ofile, &dummy, WRITE);
   ret = writePakBinFileHeader(df_o, 1);
   ret = readDataSetHeader(df_i, &nDataSets);
   ret = writeDataSetHeader(df_o, 1);
   inDataSet = readOneDataSet(df_i);
   ret = writeOneDataSet(df_o, inDataSet);

   freeBinPakData(inDataSet);
   closePakBinFile(df_i);
   closePakBinFile(df_o);
   
   exit(0);
}

