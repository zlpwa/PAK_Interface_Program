/*****************************************************************/
/*   Copyright (C) 2000, Mueller BBM VibroAkustik Systeme GmbH   */
/*   All rights reserved.                                        */
/*   This is code to read and write data via the binary          */
/*   programing interface to the arithmetic module of PAK (R)    */
/*   used by READ_DATA_FILE() and  WRITE_DATA_FILE().            */
/*   For improvements this code may be subject to changes in     */
/*   future versions.                                            */
/*****************************************************************/

/* Revision 1.2  2000/08/22 */

#ifndef _rw_data_INCLUDED_
#define _rw_data_INCLUDED_

struct binPakData {
   char name[256];   /* Name of data set */
   int      xCplx;   /* At the moment only real x-Values supported ==> xCplx = 1 */
   long        nx;   /* Number of x-Values in xdata           */
   double  *xdata;   /* x-Values  (nx * xCplx double values)  */
   int      zCplx;   /* At the moment only real z-Values supported ==> zCplx = 1 */
   long        nz;   /* Number of z-Values in zdata           */
   double  *zdata;   /* z-Values  (nz * zCplx double values)  */
   int      yCplx;   /* real or complex y-Values ==> yCplx = 1 or yCplx = 2*/
   double **ydata;   /* Array of nz double Vectors, each with nx * yCplx double values */
};

#define READ  1
#define WRITE 2

#define SUPPORTED_PAK_BIN_VERSION  1

/* Zach Philip edit below > */
// DLL import/export macros disabled for standalone build
// Uncomment this block if building or using a DLL
/*
#ifdef _WIN32
  #ifdef _MAIN_rw_data
    #define _EXT_rw_data_ __declspec(dllexport)
  #else
    #define _EXT_rw_data_ __declspec(dllimport)
  #endif
#else
  #define _EXT_rw_data_
#endif
*/

#define _EXT_rw_data_

_EXT_rw_data_ void closePakBinFile(int df);
_EXT_rw_data_ void freeBinPakData(struct binPakData* pData);
_EXT_rw_data_ int openPakBinFile(char *filename, short *nDataArrays, int oMode);
_EXT_rw_data_ struct binPakData *readDataSetData(int df);
_EXT_rw_data_ int readDataSetHeader(int df, long *nDataSets);
_EXT_rw_data_ int readDataSetName(int df, char *dsName);
_EXT_rw_data_ int readDataSetDataInfo(int df, int *cplx, long *nVal);
_EXT_rw_data_ double *readDataSetDataValues(int df, int cplx, long nVal);
_EXT_rw_data_ struct binPakData *readOneDataSet(int df);
_EXT_rw_data_ int writeDataSetData(int df, struct binPakData *pData);
_EXT_rw_data_ int writeDataSetHeader(int df, long nDataSets);
_EXT_rw_data_ int writeDataSetName(int df, char *dsName);
_EXT_rw_data_ int writeDataSetDataInfo(int df, int cplx, long nVal);
_EXT_rw_data_ int writeDataSetDataValues(int df, int cplx, long nVal, double *data);
_EXT_rw_data_ int writeOneDataSet(int df, struct binPakData *pData);
_EXT_rw_data_ int writePakBinFileHeader(int df, short nDataArrays);
#undef _EXT_rw_data_



#ifdef __cplusplus
}
#endif

#endif   /* ifndef _rw_data_INCLUDED_ */